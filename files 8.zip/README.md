# BuildBay: e-commerce app and security testing lab

## Run
```bash
npm install
npm start            # http://localhost:3000
```
Requires Node 18+. `better-sqlite3` ships prebuilt binaries for most platforms.

## Accounts
- Admin: `admin` / `admin` (seeded on first start; override with `ADMIN_USER` / `ADMIN_PASS`). **Lab use only, run on localhost.**
- Users: register from the store (email + password of 8+ characters).

## Modes
| `LAB_MODE` | Behaviour |
|---|---|
| `true` (default) | `POST /api/orders` trusts the client's `total`. Intercept it in Burp Suite, change `total`, and the success modal shows the tampered amount that was stored and logged. |
| `false` | Server recalculates the total from its own catalog. Use this to verify the fix. |

Run secure mode: `LAB_MODE=false npm start`

## Burp Suite walkthrough
1. Point your browser proxy at Burp, then browse to `http://localhost:3000`.
2. Log in, add items, and check out with Intercept on.
3. In the `POST /api/orders` request, change `"total": 1234.5` to `"total": 0.01` and forward it.
4. The modal shows `$0.01`. Check the admin dashboard's Orders table and Live Traffic log to see the tampered request.
5. Repeat with `LAB_MODE=false` and the server ignores your value.

## Security controls in place
- bcrypt password hashing, session cookie (`httpOnly`, `sameSite=lax`), session regeneration on login.
- Admin check re-reads the role from the DB on every admin request. The role is never accepted from client input.
- Every user-data query uses `WHERE user_id = ?` with the session's id, and all SQL is parameterized.
- Admin page is served from a non-public folder, only to admins.
- Passwords are redacted from traffic logs. Output is HTML-escaped (XSS) and a strict CSP is set.

## Known limits (add before any non-lab deployment)
- No login rate limiting or CSRF tokens, and the session store is in memory.
- Default `admin/admin` credentials.
- Product images come from picsum.photos (random photos, not matched to products, and I can't guarantee availability). The UI falls back to a placeholder if one fails. Swap in your own URLs in `server.js`.
