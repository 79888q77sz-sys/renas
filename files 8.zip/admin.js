const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

async function get(url) {
  const r = await fetch(url, { credentials: 'same-origin' });
  if (r.status === 401 || r.status === 403) { location.href = '/'; throw new Error('forbidden'); }
  return r.json();
}
const table = (el, head, rows) => {
  $(el).innerHTML = `<tr>${head.map(h => `<th>${h}</th>`).join('')}</tr>` +
    rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('');
};

async function loadStatic() {
  const [users, orders] = await Promise.all([get('/api/admin/users'), get('/api/admin/orders')]);
  table('#users', ['ID', 'Email', 'Role', 'Created'],
    users.map(u => [u.id, esc(u.email), esc(u.role), esc(u.created_at)]));
  table('#orders', ['ID', 'User', 'Customer', 'Phone', 'Address', 'Payment', 'Items', 'Total', 'Created'],
    orders.map(o => [o.id, esc(o.email), esc(o.customer_name), esc(o.phone), esc(o.address),
      esc(o.payment_method), `<code>${esc(o.items_json)}</code>`, '$' + Number(o.total_amount).toFixed(2), esc(o.created_at)]));
}
async function loadTraffic() {
  const logs = await get('/api/admin/traffic');
  table('#traffic', ['Time', 'User', 'IP', 'Method', 'Endpoint', 'Payload'],
    logs.map(l => [esc(l.timestamp), esc(l.email || 'anonymous'), esc(l.ip_address), esc(l.method),
      esc(l.endpoint), `<code>${esc(l.payload)}</code>`]));
}

$('#logout').onclick = async () => {
  await fetch('/api/logout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
  location.href = '/';
};
(async () => {
  const me = await get('/api/me');
  if (!me.user || me.user.role !== 'admin') return (location.href = '/');
  $('#me').textContent = me.user.email;
  await Promise.all([loadStatic(), loadTraffic()]);
  setInterval(loadTraffic, 3000);
  setInterval(loadStatic, 10000);
})();
