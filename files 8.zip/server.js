// BuildBay - e-commerce app + security testing lab
// LAB_MODE=true (default): checkout trusts the client-supplied `total` (price tampering lab).
// LAB_MODE=false: server recalculates the total from its own catalog (secure behaviour).
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const crypto = require('crypto');
const path = require('path');

const PORT = process.env.PORT || 3000;
const LAB_MODE = process.env.LAB_MODE !== 'false';
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASS || 'admin'; // LAB ONLY - change for anything non-local

const db = new Database(path.join(__dirname, 'buildbay.db'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user','admin')),
  created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS orders(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id),
  customer_name TEXT, phone TEXT, address TEXT, payment_method TEXT,
  items_json TEXT, total_amount REAL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS traffic_logs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER, ip_address TEXT, method TEXT, endpoint TEXT, payload TEXT,
  timestamp TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
`);
if (!db.prepare('SELECT 1 FROM users WHERE email=?').get(ADMIN_USER)) {
  db.prepare('INSERT INTO users(email,password_hash,role) VALUES(?,?,?)')
    .run(ADMIN_USER, bcrypt.hashSync(ADMIN_PASS, 10), 'admin');
}

// ---------- Catalog (server-side source of truth for prices) ----------
const raw = [
  ['Ryzen 7 7800X3D CPU','PC Parts',399],['Core i7-14700K CPU','PC Parts',379],
  ['RTX 4070 Super GPU','PC Parts',599],['RX 7800 XT GPU','PC Parts',489],
  ['32GB DDR5 6000 RAM Kit','PC Parts',119],['2TB NVMe Gen4 SSD','PC Parts',139],
  ['850W Gold PSU','PC Parts',129],['Mid-Tower Airflow Case','PC Parts',99],
  ['Mechanical Keyboard','Electronics',89],['Wireless Gaming Mouse','Electronics',59],
  ['27" 1440p 165Hz Monitor','Electronics',279],['Noise-Cancelling Headphones','Electronics',199],
  ['Bluetooth Speaker','Electronics',49],['4K Webcam','Electronics',89],
  ['Smartwatch Series X','Electronics',229],['USB-C Docking Station','Electronics',109],
  ['Classic Denim Jacket','Fashion',79],['Leather Chelsea Boots','Fashion',149],
  ['Cotton Crew Tee 3-Pack','Fashion',34],['Minimal Sneakers','Fashion',89],
  ['Beard Trimmer Pro','Grooming',49],['Electric Shaver','Grooming',99],
  ['Hair Clipper Kit','Grooming',44],['Beard Oil & Balm Set','Grooming',24],
].map(([name, category, price], i) => ({ id: i + 1, name, category, price,
  image: `https://picsum.photos/seed/buildbay${i + 1}/480/320` }));
const catalog = new Map(raw.map(p => [p.id, p]));

// ---------- App ----------
const app = express();
app.disable('x-powered-by');
app.set('trust proxy', false);
app.use(express.json({ limit: '50kb' }));
app.use(session({
  name: 'bb.sid',
  secret: process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex'),
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', maxAge: 2 * 3600 * 1000 }
}));
app.use((req, res, next) => {
  res.set({ 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'same-origin',
    'Content-Security-Policy': "default-src 'self'; img-src 'self' https: data:; style-src 'self'; script-src 'self'" });
  next();
});

// Traffic logger: every /api request, with sensitive fields redacted
const logStmt = db.prepare('INSERT INTO traffic_logs(user_id,ip_address,method,endpoint,payload) VALUES(?,?,?,?,?)');
app.use('/api', (req, res, next) => {
  if (req.originalUrl.startsWith('/api/admin/traffic')) return next(); // avoid self-noise from polling
  const body = { ...(req.body || {}) };
  if ('password' in body) body.password = '[REDACTED]';
  res.on('finish', () => {
    try {
      logStmt.run(req.session?.userId ?? null, req.ip, req.method, req.originalUrl,
        JSON.stringify(body).slice(0, 2000));
    } catch (e) { console.error('log error', e.message); }
  });
  next();
});

// ---------- Auth middleware ----------
const requireAuth = (req, res, next) =>
  req.session.userId ? next() : res.status(401).json({ error: 'Authentication required' });
const requireAdmin = (req, res, next) => {
  if (!req.session.userId) return res.status(401).json({ error: 'Authentication required' });
  const u = db.prepare('SELECT role FROM users WHERE id=?').get(req.session.userId); // re-check in DB, never trust client
  return u && u.role === 'admin' ? next() : res.status(403).json({ error: 'Forbidden' });
};

// ---------- Auth routes ----------
app.post('/api/register', (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 120)
    return res.status(400).json({ error: 'Valid email required' });
  if (password.length < 8 || password.length > 100)
    return res.status(400).json({ error: 'Password must be 8-100 characters' });
  try {
    const info = db.prepare('INSERT INTO users(email,password_hash,role) VALUES(?,?,?)')
      .run(email, bcrypt.hashSync(password, 10), 'user'); // role is never taken from the request
    req.session.regenerate(() => {
      req.session.userId = info.lastInsertRowid;
      res.status(201).json({ id: info.lastInsertRowid, email, role: 'user' });
    });
  } catch { res.status(409).json({ error: 'Email already registered' }); }
});

app.post('/api/login', (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  const ok = user && bcrypt.compareSync(String(req.body.password || ''), user.password_hash);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  req.session.regenerate(() => {
    req.session.userId = user.id;
    res.json({ id: user.id, email: user.email, role: user.role,
      redirect: user.role === 'admin' ? '/admin' : '/' });
  });
});

app.post('/api/logout', (req, res) => req.session.destroy(() => res.clearCookie('bb.sid').json({ ok: true })));

app.get('/api/me', (req, res) => {
  if (!req.session.userId) return res.json({ user: null, labMode: LAB_MODE });
  const u = db.prepare('SELECT id,email,role,created_at FROM users WHERE id=?').get(req.session.userId);
  res.json({ user: u || null, labMode: LAB_MODE });
});

// ---------- Store routes ----------
app.get('/api/products', (req, res) => res.json(raw));

app.post('/api/orders', requireAuth, (req, res) => {
  const { customer_name, phone, address, payment_method, items, total } = req.body;
  if (![customer_name, phone, address].every(v => typeof v === 'string' && v.trim() && v.length <= 200))
    return res.status(400).json({ error: 'Name, phone and address are required' });
  if (!['FastPay', 'Visa Card', 'Cash on Delivery'].includes(payment_method))
    return res.status(400).json({ error: 'Invalid payment method' });
  if (!Array.isArray(items) || !items.length || items.length > 50)
    return res.status(400).json({ error: 'Cart is empty' });

  let serverTotal = 0; const lines = [];
  for (const it of items) {
    const p = catalog.get(Number(it.id)); const qty = Number(it.qty);
    if (!p || !Number.isInteger(qty) || qty < 1 || qty > 20)
      return res.status(400).json({ error: 'Invalid cart item' });
    serverTotal += p.price * qty;
    lines.push({ id: p.id, name: p.name, qty, unit_price: p.price });
  }
  // INTENTIONAL LAB VULNERABILITY (LAB_MODE=true): client-controlled total is trusted.
  const useClient = LAB_MODE && typeof total === 'number' && isFinite(total) && total >= 0;
  const finalTotal = Math.round((useClient ? total : serverTotal) * 100) / 100;

  const info = db.prepare(`INSERT INTO orders(user_id,customer_name,phone,address,payment_method,items_json,total_amount)
    VALUES(?,?,?,?,?,?,?)`).run(req.session.userId, customer_name.trim(), phone.trim(), address.trim(),
    payment_method, JSON.stringify(lines), finalTotal);
  res.status(201).json({ orderId: info.lastInsertRowid, total: finalTotal, payment_method, items: lines });
});

// Strict isolation: always filtered by the session's user_id
app.get('/api/orders', requireAuth, (req, res) => {
  res.json(db.prepare('SELECT id,customer_name,payment_method,items_json,total_amount,created_at FROM orders WHERE user_id = ? ORDER BY id DESC')
    .all(req.session.userId));
});

// ---------- Admin routes ----------
app.get('/api/admin/users', requireAdmin, (req, res) =>
  res.json(db.prepare('SELECT id,email,role,created_at FROM users ORDER BY id DESC').all()));
app.get('/api/admin/orders', requireAdmin, (req, res) =>
  res.json(db.prepare(`SELECT o.*, u.email FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC`).all()));
app.get('/api/admin/traffic', requireAdmin, (req, res) =>
  res.json(db.prepare(`SELECT t.*, u.email FROM traffic_logs t LEFT JOIN users u ON u.id=t.user_id ORDER BY t.id DESC LIMIT 200`).all()));

app.get('/api/*', (req, res) => res.status(404).json({ error: 'Not found' }));

// Admin page is served only to admins (not in the public folder)
app.get('/admin', (req, res) => {
  const u = req.session.userId && db.prepare('SELECT role FROM users WHERE id=?').get(req.session.userId);
  if (!u || u.role !== 'admin') return res.redirect('/');
  res.sendFile(path.join(__dirname, 'private', 'admin.html'));
});
app.use(express.static(path.join(__dirname, 'public')));

app.listen(PORT, () => console.log(`BuildBay on http://localhost:${PORT}  (LAB_MODE=${LAB_MODE})`));
