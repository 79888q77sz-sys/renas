const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = n => '$' + Number(n).toFixed(2);
const FALLBACK = "data:image/svg+xml;utf8," + encodeURIComponent(
  "<svg xmlns='http://www.w3.org/2000/svg' width='480' height='320'><rect width='100%' height='100%' fill='#1b2230'/><text x='50%' y='50%' fill='#5d6b86' font-family='sans-serif' font-size='22' text-anchor='middle'>BuildBay</text></svg>");

let user = null, products = [], cat = 'All', cart = {}, signup = false;
const cartKey = () => 'bb_cart_' + (user ? user.id : 'guest');
const saveCart = () => localStorage.setItem(cartKey(), JSON.stringify(cart));
const loadCart = () => { try { cart = JSON.parse(localStorage.getItem(cartKey())) || {}; } catch { cart = {}; } };

async function api(url, opts = {}) {
  const r = await fetch(url, { headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin', ...opts });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function renderNav() {
  const cats = ['All', ...new Set(products.map(p => p.category))];
  $('#cats').innerHTML = cats.map(c => `<button class="${c === cat ? 'active' : ''}" data-cat="${esc(c)}">${esc(c)}</button>`).join('');
}
function renderGrid() {
  $('#grid').innerHTML = products.filter(p => cat === 'All' || p.category === cat).map(p => `
    <article class="card"><img loading="lazy" src="${esc(p.image)}" alt="${esc(p.name)}">
    <div class="info"><small>${esc(p.category)}</small><h3>${esc(p.name)}</h3>
    <div class="row"><b>${money(p.price)}</b><button data-add="${p.id}">Add to cart</button></div></div></article>`).join('');
  document.querySelectorAll('img').forEach(i => i.onerror = () => { i.onerror = null; i.src = FALLBACK; });
}
const cartLines = () => Object.entries(cart).map(([id, qty]) => ({ p: products.find(x => x.id == id), qty })).filter(l => l.p);
const cartTotal = () => cartLines().reduce((s, l) => s + l.p.price * l.qty, 0);
function renderCart() {
  $('#cartCount').textContent = cartLines().reduce((s, l) => s + l.qty, 0);
  $('#cartItems').innerHTML = cartLines().map(l => `<div class="line"><span>${esc(l.p.name)} × ${l.qty}</span>
    <span>${money(l.p.price * l.qty)} <button class="ghost" data-rm="${l.p.id}">✕</button></span></div>`).join('') || '<p>Cart is empty.</p>';
  $('#cartTotal').textContent = money(cartTotal());
}
function renderAuth() {
  $('#who').textContent = user ? user.email : '';
  $('#authBtn').textContent = user ? 'Sign out' : 'Sign in';
  $('#ordersBtn').hidden = !user;
}

document.addEventListener('click', async e => {
  const t = e.target;
  if (t.dataset.cat) { cat = t.dataset.cat; renderNav(); renderGrid(); }
  if (t.dataset.add) { cart[t.dataset.add] = Math.min((cart[t.dataset.add] || 0) + 1, 20); saveCart(); renderCart(); }
  if (t.dataset.rm) { delete cart[t.dataset.rm]; saveCart(); renderCart(); }
  if (t.hasAttribute('data-close')) t.closest('dialog').close();
});
$('#cartBtn').onclick = () => { renderCart(); $('#cartDlg').showModal(); };
$('#toggleAuth').onclick = () => {
  signup = !signup;
  $('#authTitle').textContent = signup ? 'Create account' : 'Sign in';
  $('#toggleAuth').textContent = signup ? 'I have an account' : 'Create account';
};
$('#authBtn').onclick = async () => {
  if (user) { await api('/api/logout', { method: 'POST' }); user = null; loadCart(); renderAuth(); renderCart(); return; }
  $('#authErr').textContent = ''; $('#authDlg').showModal();
};
$('#authForm').onsubmit = async e => {
  e.preventDefault();
  try {
    const body = JSON.stringify({ email: $('#email').value, password: $('#password').value });
    const r = await api(signup ? '/api/register' : '/api/login', { method: 'POST', body });
    if (r.redirect === '/admin') return (location.href = '/admin');
    user = { id: r.id, email: r.email, role: r.role };
    $('#authDlg').close(); $('#password').value = ''; loadCart(); renderAuth(); renderCart();
  } catch (err) { $('#authErr').textContent = err.message; }
};
$('#checkoutBtn').onclick = () => {
  if (!cartLines().length) return;
  if (!user) { $('#cartDlg').close(); $('#authDlg').showModal(); return; }
  $('#cartDlg').close(); $('#coErr').textContent = ''; $('#checkoutDlg').showModal();
};
$('#checkoutForm').onsubmit = async e => {
  e.preventDefault();
  const f = Object.fromEntries(new FormData(e.target));
  const payload = { ...f, items: cartLines().map(l => ({ id: l.p.id, qty: l.qty })), total: cartTotal() };
  try {
    const r = await api('/api/orders', { method: 'POST', body: JSON.stringify(payload) });
    // Success modal reflects the total the BACKEND processed
    $('#okBody').innerHTML = `<p>Order #${esc(r.orderId)} via ${esc(r.payment_method)}</p><p class="total">Processed total: <b>${money(r.total)}</b></p>`;
    cart = {}; saveCart(); renderCart(); $('#checkoutDlg').close(); $('#okDlg').showModal();
  } catch (err) { $('#coErr').textContent = err.message; }
};
$('#ordersBtn').onclick = async () => {
  const rows = await api('/api/orders');
  $('#ordersBody').innerHTML = rows.map(o => `<div class="line"><span>#${o.id} · ${esc(o.payment_method)} · ${esc(o.created_at)}</span><b>${money(o.total_amount)}</b></div>`).join('') || '<p>No orders yet.</p>';
  $('#ordersDlg').showModal();
};

(async function init() {
  const me = await api('/api/me');
  if (me.user && me.user.role === 'admin') return (location.href = '/admin');
  user = me.user; products = await api('/api/products');
  loadCart(); renderAuth(); renderNav(); renderGrid(); renderCart();
})();
